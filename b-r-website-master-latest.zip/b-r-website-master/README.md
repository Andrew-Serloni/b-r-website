Bionic Reading Converter by Andrew Serloni

Made for the 2022 Capstone Project in my AP CSA class.